const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const data = require("./data");

const app = express();
const PORT = 4131;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "resources")));

app.set("view engine", "pug");
app.set("views", path.join(__dirname, "templates"));

let rateLimitStore = [];
function enforceRateLimit() {
    const RATE_LIMIT = 4;
    const RATE_LIMIT_WINDOW = 10 * 1000; 
    const now = Date.now();

    rateLimitStore = rateLimitStore.filter((timestamp) => now - timestamp < RATE_LIMIT_WINDOW);
    if (rateLimitStore.length >= RATE_LIMIT) {
        const retryAfter = (RATE_LIMIT_WINDOW - (now - rateLimitStore[0])) / 1000;
        return retryAfter;
    }
    rateLimitStore.push(now);
    return 0;
}


// main page
app.get(["/", "/main"], (req, res) => {
    res.render("mainpage");
});

// gallery 
app.get("/gallery", async (req, res) => {
    const { query, category } = req.query;

    try {
        const listings = await data.getGallery(query, category);
        res.render("gallery", { listings });
    } catch (error) {
        console.error("Error fetching gallery:", error);
        res.status(500).send("Server error while fetching gallery");
    }
});

// Individual listing page
app.get("/listing/:id", async (req, res) => {
    const listingId = parseInt(req.params.id, 10);

    try {
        const listing = await data.getListing(listingId);
        if (!listing) {
            return res.status(404).render("404");
        }

        const bidderName = req.cookies.bidder_name || "";
        res.render("listing", { listing, bidderName });
    } catch (error) {
        console.error("Error fetching listing:", error);
        res.status(500).send("Server error while fetching listing");
    }
});

// Create a new listing form
app.get("/create", (req, res) => {
    res.render("create");
});

// Submit new listing
app.post("/create", async (req, res) => {
    const { title, image_url, description, category, end_date } = req.body;

    if (!title || !image_url || !description || !category || !end_date) {
        return res.status(400).render("create_fail");
    }

    try {
        const newListingId = await data.addListing({ title, image_url, description, category, end_date });
        res.render("create_success", { listing_id: newListingId });
    } catch (error) {
        console.error("Error creating listing:", error);
        res.status(500).render("create_fail");
    }
});

// Place a bid
app.post("/api/place_bid", async (req, res) => {
    const { listing_id, bidder_name, bid_amount, comment } = req.body;

    if (!listing_id || !bidder_name || !bid_amount) {
        return res.status(400).json({ error: "Missing required fields" });
    }

    try {
        const result = await data.placeBid({ listing_id, bidder: bidder_name, amount: bid_amount, comment });
        if (!result.success) {
            return res.status(409).json({ error: "Bid too low or auction closed" });
        }

        res.cookie("bidder_name", bidder_name).json(result.bids);
    } catch (error) {
        console.error("Error placing bid:", error);
        res.status(500).json({ error: "Server error while placing bid" });
    }
});

// Delete a listing
app.delete("/api/delete_listing", async (req, res) => {
    const { listing_id } = req.body;

    if (!listing_id || typeof listing_id !== "number") {
        return res.status(400).json({ error: "Invalid listing ID" });
    }

    const rateLimit = enforceRateLimit();
    if (rateLimit > 0) {
        res.setHeader("Retry-After", rateLimit);
        return res.status(429).json({ error: "Rate limit exceeded" });
    }

    try {
        const success = await data.deleteListing(listing_id);
        if (!success) {
            return res.status(404).json({ error: "Listing not found" });
        }

        res.status(204).send();
    } catch (error) {
        console.error("Error deleting listing:", error);
        res.status(500).json({ error: "Server error while deleting listing" });
    }
});

// Handle unknown routes
app.use((req, res) => {
    res.status(404).render("404");
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
