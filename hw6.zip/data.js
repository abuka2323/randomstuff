// this package behaves just like the mysql one, but uses async await instead of callbacks.
const mysql = require(`mysql-await`); // npm install mysql-await

// first -- I want a connection pool: https://www.npmjs.com/package/mysql#pooling-connections
// this is used a bit differently, but I think it's just better -- especially if server is doing heavy work.
var connPool = mysql.createPool({
  connectionLimit: 5, // it's a shared resource, let's not go nuts.
  host: "127.0.0.1",// this will work
  user: "abuka032",
  database: "proj4131",
  password: "Kobebronbryant23-!!", // we really shouldn't be saving this here long-term -- and I probably shouldn't be sharing it with you...
});

// later you can use connPool.awaitQuery(query, data) -- it will return a promise for the query results.


// Add a new listing
async function addListing(data) {
  const { title, image, description, category, sale_date, end_time } = data;
  const query = `
      INSERT INTO auction (title, image_url, description, category, sale_date, end_time)
      VALUES (?, ?, ?, ?, ?, ?)
  `;
  const result = await connPool.awaitQuery(query, [title, image, description, category, sale_date, end_time]);
  return result.insertId; // Return the ID of the new listing
}

// Delete a listing by ID
async function deleteListing(id) {
  const query = `
      DELETE FROM auction
      WHERE id = ?
  `;
  const result = await connPool.awaitQuery(query, [id]);
  return result.affectedRows > 0; // Return true if rows were affected
}

// Get a single listing by ID
async function getListing(id) {
  // Query for the listing
  const listingQuery = `
      SELECT * FROM auction
      WHERE id = ?
  `;
  const listingResult = await connPool.awaitQuery(listingQuery, [id]);

  if (listingResult.length === 0) {
      return null; // Listing not found
  }

  // Query for the bids associated with the listing
  const bidsQuery = `
      SELECT * FROM bid
      WHERE auction_id = ?
      ORDER BY amount DESC, created_at DESC
  `;
  const bidsResult = await connPool.awaitQuery(bidsQuery, [id]);

  const listing = listingResult[0];
  listing.bids = bidsResult;

  return listing;
}

async function getGallery(query, category) {
  let sql = `
      SELECT * FROM auction
      WHERE 1=1
  `;
  const params = [];

  if (query) {
      sql += ` AND title LIKE ?`;
      params.push(`%${query}%`);
  }

  if (category && category.toLowerCase() !== "all") {
      sql += ` AND category = ?`;
      params.push(category);
  }

  return await connPool.awaitQuery(sql, params);
}

async function placeBid(data) {
  const { listing_id, bidder, amount, comment } = data;

  // Check if listing exists
  const listingQuery = `
      SELECT * FROM auction
      WHERE id = ?
  `;
  const listingResult = await connPool.awaitQuery(listingQuery, [listing_id]);

  if (listingResult.length === 0) {
      throw new Error("Listing not found");
  }

  // Insert the bid
  const bidQuery = `
      INSERT INTO bid (auction_id, bidder, amount, comment)
      VALUES (?, ?, ?, ?)
  `;
  const result = await connPool.awaitQuery(bidQuery, [listing_id, bidder, amount, comment]);
  return result.insertId;
}

// Get all bids for a specific listing
async function getBids(listing_id) {
  const query = `
      SELECT * FROM bid
      WHERE auction_id = ?
      ORDER BY amount DESC, created_at DESC
  `;
  return await connPool.awaitQuery(query, [listing_id]);
}

// Get the highest bid for a specific listing
async function getHighestBid(listing_id) {
  const query = `
      SELECT MAX(amount) AS highest_bid
      FROM bid
      WHERE auction_id = ?
  `;
  const result = await connPool.awaitQuery(query, [listing_id]);
  return result[0]?.highest_bid || 0; // Return the highest bid or 0 if no bids
}

// Export the functions
module.exports = {
  addListing,
  deleteListing,
  getListing,
  getGallery,
  placeBid,
  getBids,
  getHighestBid
};