document.addEventListener("DOMContentLoaded", () => {
    const deleteButtons = document.querySelectorAll(".delete-button");

    deleteButtons.forEach(button => {
        button.addEventListener("click", (event) => {
            const row = button.closest(".listing-row");
            const listingId = row.getAttribute("data-listing-id");

            if (confirm("Are you sure you want to delete this listing?")) {
                fetch("/api/delete_listing", {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ listing_id: parseInt(listingId) })
                })
                .then(response => {
                    if (response.status === 204 || response.status === 404) {
                        row.remove();  
                    } else {
                        alert("An error occurred while trying to delete the listing.");
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred while trying to delete the listing.");
                });
            }
        });
    });
});
