document.addEventListener("DOMContentLoaded", function() {
    const toggleButton = document.getElementById("toggle-bid-button");
    const bidFormContainer = document.getElementById("bid-form-container");
    const bidForm = document.getElementById("bid-form");
    const bidsContainer = document.querySelector(".bids");
    const amountInput = document.getElementById("amount");

    toggleButton.addEventListener("click", function() {
        bidFormContainer.style.display = (bidFormContainer.style.display === "none") ? "block" : "none";
        toggleButton.textContent = (bidFormContainer.style.display === "block") ? "Cancel Bid" : "Place Bid";
    });

    bidForm.addEventListener("submit", function(event) {
        event.preventDefault();

        const listingId = document.getElementById("listing_id").value;
        const bidderName = document.getElementById("bidder").value;
        const bidAmount = parseFloat(amountInput.value);
        const comment = document.getElementById("comment").value;

        const bidData = {
            listing_id: parseInt(listingId, 10),
            bidder_name: bidderName,
            bid_amount: bidAmount,
            comment
        };

        fetch("/api/place_bid", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(bidData)
        })
        .then(response => {
            if (response.ok) {
                return response.json(); 
            } else if (response.status === 409) {
                throw new Error("Bid too low");
            } else {
                throw new Error("Server error");
            }
        })
        .then(bids => {
            if (Array.isArray(bids)) {
                displayBids(bids); 
                bidForm.reset(); 
                toggleButton.textContent = "Place Bid";
                bidFormContainer.style.display = "none";
            }
        })
        .catch(error => {
            alert(error.message);
            console.error("Error:", error);
        });
    });

    function displayBids(bids) {
        bidsContainer.innerHTML = ""; 
        bids.forEach(bid => {
            const bidElement = document.createElement("div");
            bidElement.classList.add("bid");

            const bidderSpan = document.createElement("span");
            bidderSpan.classList.add("bidder");
            bidderSpan.textContent = bid.bidder;

            const amountSpan = document.createElement("span");
            amountSpan.classList.add("amount");
            amountSpan.textContent = `$${bid.amount.toFixed(2)}`;

            bidElement.appendChild(bidderSpan);
            bidElement.appendChild(amountSpan);

            if (bid.comment) {
                const commentPara = document.createElement("p");
                commentPara.textContent = bid.comment;
                bidElement.appendChild(commentPara);
            }

            bidsContainer.appendChild(bidElement);
        });
    }
});
