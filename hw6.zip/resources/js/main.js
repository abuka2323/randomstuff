document.addEventListener("DOMContentLoaded", function() {
    const banner = document.getElementById("auction-banner");
    
    function toggleBannerVisibility() {
        if (banner.style.visibility === "hidden") {
            banner.style.visibility = "visible";
        } else {
            banner.style.visibility = "hidden";
        }
    }
    banner.style.visibility = "visible";
    setInterval(toggleBannerVisibility, 1000);
});
